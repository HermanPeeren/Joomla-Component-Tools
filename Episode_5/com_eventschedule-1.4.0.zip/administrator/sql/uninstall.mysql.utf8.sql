DROP TABLE IF EXISTS `#__eventschedule_eventschedules`;
DROP TABLE IF EXISTS `#__eventschedule_containers`;
DROP TABLE IF EXISTS `#__eventschedule_sections`;
DROP TABLE IF EXISTS `#__eventschedule_actors`;
DROP TABLE IF EXISTS `#__eventschedule_events`;
DROP TABLE IF EXISTS `#__eventschedule_event_types`;
